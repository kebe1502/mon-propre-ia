const CONTEXTE = require("./_contexte");

const MODEL = "claude-sonnet-5-5";
const PROMPT_BASE =
  "Tu es mon assistant personnel pour mes projets informatiques. " +
  "Réponds toujours en français, de façon claire et pédagogique. " +
  "Quand tu proposes du code, explique brièvement ce qu'il fait. " +
  "Si une demande est ambiguë, pose une question avant de te lancer. " +
  "Si tu repères un bug ou un problème dans mon code, dis-le franchement.";

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ erreur: "Méthode non autorisée." });
  }

  const { ANTHROPIC_API_KEY, ACCESS_CODE } = process.env;
  if (!ANTHROPIC_API_KEY || !ACCESS_CODE) {
    return res
      .status(500)
      .json({ erreur: "Variables ANTHROPIC_API_KEY et ACCESS_CODE à définir sur Vercel." });
  }

  const { messages, code } = req.body || {};
  if (code !== ACCESS_CODE) {
    return res.status(401).json({ erreur: "Code d'accès incorrect." });
  }
  if (
    !Array.isArray(messages) ||
    messages.length === 0 ||
    !messages.every(
      (m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string"
    )
  ) {
    return res.status(400).json({ erreur: "Messages invalides." });
  }

  // On garde les derniers messages, en commençant par un message "user".
  let recents = messages.slice(-21);
  if (recents[0].role !== "user") recents = recents.slice(1);

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1500,
        system: PROMPT_BASE + "\n\nVoici le contexte de mes projets :\n" + CONTEXTE,
        messages: recents,
      }),
    });
    const data = await r.json();
    if (!r.ok) {
      return res.status(502).json({ erreur: (data.error && data.error.message) || "Erreur API." });
    }
    const reponse = data.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("");
    return res.status(200).json({ reponse });
  } catch (e) {
    return res.status(500).json({ erreur: "Erreur serveur : " + e.message });
  }
};
