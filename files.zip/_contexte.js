// Modifie ce texte avec les infos de ton projet, puis redéploie.
module.exports = `
# Mon profil
- Étudiant en Licence 2 Informatique
- Matières : développement web, algorithmique et structures de données, réseaux, analyse numérique, statistiques, systèmes d'exploitation

# Mon projet en cours
- Nom : (à remplir)
- Objectif : (à remplir)
- Technologies utilisées : (à remplir)
- Contraintes / date de rendu : (à remplir)
- Ce qui est déjà fait : (à remplir)
- Ce qui bloque : (à remplir)

# Mes préférences
- Explique-moi le raisonnement, pas seulement la solution.
- Donne des exemples de code courts et commentés.
`;
